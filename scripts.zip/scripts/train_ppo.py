import argparse
import sys
from collections import deque
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback, EvalCallback
from stable_baselines3.common.env_util import make_vec_env

from mapark.rl_env import ParkingEnv
from mapark.sensors import sense_all

MAX_EPISODES = 3_000
MAX_EPISODE_STEPS = 400


class TrainingRenderCallback(BaseCallback):
    def __init__(self, progress_callback):
        super().__init__()
        self.progress_callback = progress_callback
        self.enabled = True

    def _on_training_start(self):
        import pygame

        from render2d.app import draw_world

        self.pygame = pygame
        self.draw_world = draw_world
        pygame.init()
        self.screen = pygame.display.set_mode((900, 650))
        pygame.display.set_caption("PPO parking training - ESC to stop")
        self.font = pygame.font.SysFont("consolas", 16)
        self.clock = pygame.time.Clock()

    def _on_step(self):
        pygame = self.pygame
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (
                event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE
            ):
                self.enabled = False

        if not self.enabled:
            return False

        world = self.training_env.get_attr("world")[0]
        world.sensors = sense_all(world, world.car, max_range=180.0)
        self.draw_world(self.screen, world)

        episodes = self.progress_callback.episodes
        recent = list(self.progress_callback.recent_episodes)
        if recent:
            success_rate = sum(item[0] for item in recent) / len(recent)
            collision_rate = sum(item[1] for item in recent) / len(recent)
        else:
            success_rate = collision_rate = 0.0
        done = bool(self.locals["dones"][0])
        info = self.locals["infos"][0] if done else {}
        outcome = (
            "PARKED"
            if info.get("is_success")
            else "COLLISION"
            if info.get("collision")
            else "Training"
        )

        lines = [
            f"Episode: {episodes}/{MAX_EPISODES}  Current: {outcome}",
            f"Success (recent {len(recent)}): {success_rate:.0%}",
            f"Collision (recent {len(recent)}): {collision_rate:.0%}",
            "ESC: stop and save progress",
        ]
        for index, text in enumerate(lines):
            image = self.font.render(text, True, (20, 20, 20))
            self.screen.blit(image, (10, 10 + index * 22))
        pygame.display.flip()
        self.clock.tick(60)
        return True

    def _on_training_end(self):
        self.pygame.quit()


class EpisodeProgressCallback(BaseCallback):
    def __init__(self, max_episodes, start_episode, progress_path, progress_file):
        super().__init__()
        self.max_episodes = max_episodes
        self.episodes = start_episode
        self.progress_path = progress_path
        self.progress_file = progress_file
        self.recent_episodes = deque(maxlen=100)

    def _on_step(self):
        for done, info in zip(self.locals["dones"], self.locals["infos"]):
            if not done:
                continue
            episode = info["episode"]
            self.episodes += 1
            self.recent_episodes.append(
                (
                    bool(info["is_success"]),
                    bool(info["collision"]),
                    float(episode["r"]),
                )
            )

            if self.episodes % 100 == 0:
                recent = list(self.recent_episodes)
                success_rate = sum(item[0] for item in recent) / len(recent)
                collision_rate = sum(item[1] for item in recent) / len(recent)
                mean_reward = sum(item[2] for item in recent) / len(recent)
                print(
                    f"Episodes {self.episodes}/{self.max_episodes} | "
                    f"success last 100: {success_rate:.0%} | "
                    f"collision last 100: {collision_rate:.0%} | "
                    f"mean reward: {mean_reward:.1f}"
                )
                self.logger.record("train/success_rate_last_100", success_rate)
                self.logger.record("train/collision_rate_last_100", collision_rate)
                self.logger.record("train/mean_reward_last_100", mean_reward)
                self.model.save(str(self.progress_path))
                self.progress_file.write_text(str(self.episodes), encoding="utf-8")

            if self.episodes >= self.max_episodes:
                return False
        return True

    def _on_training_end(self):
        if self.episodes < self.max_episodes:
            self.model.save(str(self.progress_path))
            self.progress_file.write_text(str(self.episodes), encoding="utf-8")


def load_config():
    with (ROOT / "configs" / "default.yaml").open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def main():
    parser = argparse.ArgumentParser(
        description="Train the parking agent and optionally show each episode."
    )
    parser.add_argument(
        "--fresh",
        action="store_true",
        help="Start a new PPO policy instead of resuming saved training.",
    )
    parser.add_argument(
        "--render",
        action="store_true",
        help="Show the car and rolling success/collision rates during training.",
    )
    args = parser.parse_args()

    cfg = load_config()
    n_envs = 1
    models_dir = ROOT / "models"
    models_dir.mkdir(exist_ok=True)
    final_path = models_dir / "ppo_park_v4_final.zip"
    progress_path = models_dir / "ppo_park_v4_progress.zip"
    progress_file = models_dir / "ppo_park_v4_episodes.txt"

    if final_path.exists() and not args.fresh:
        print(f"Training already reached its target. Model: {final_path.name}")
        return

    start_episode = 0 if args.fresh else (
        int(progress_file.read_text(encoding="utf-8"))
        if progress_file.exists()
        else 0
    )
    if start_episode > 0 and not progress_path.exists():
        raise FileNotFoundError(
            "Training progress count exists, but its matching model checkpoint is missing."
        )
    if start_episode >= MAX_EPISODES:
        PPO.load(str(progress_path)).save(str(final_path.with_suffix("")))
        print(f"Training already reached {MAX_EPISODES} episodes.")
        return

    env = make_vec_env(
        ParkingEnv,
        n_envs=n_envs,
        seed=7,
        env_kwargs={"config": cfg},
        monitor_kwargs={"info_keywords": ("is_success", "collision")},
    )
    eval_env = make_vec_env(
        ParkingEnv,
        n_envs=1,
        seed=10_007,
        env_kwargs={"config": cfg},
        monitor_kwargs={"info_keywords": ("is_success", "collision")},
    )

    if not args.fresh and progress_path.exists() and start_episode < MAX_EPISODES:
        model = PPO.load(
            str(progress_path),
            env=env,
            tensorboard_log=str(ROOT / "runs"),
        )
        print(f"Continuing from episode {start_episode}/{MAX_EPISODES}")
    else:
        start_episode = 0
        model = PPO(
            "MlpPolicy",
            env,
            verbose=1,
            learning_rate=3e-4,
            n_steps=2048,
            batch_size=256,
            n_epochs=10,
            gamma=0.99,
            gae_lambda=0.95,
            clip_range=0.2,
            ent_coef=0.01,
            policy_kwargs=dict(net_arch=[64, 64]),
            tensorboard_log=str(ROOT / "runs"),
        )

    checkpoint_cb = CheckpointCallback(
        save_freq=20_000,
        save_path=str(models_dir),
        name_prefix="ppo_park_v4",
    )
    eval_cb = EvalCallback(
        eval_env,
        best_model_save_path=str(models_dir / "best_v4"),
        log_path=str(ROOT / "runs" / "eval"),
        eval_freq=10_000,
        n_eval_episodes=20,
        deterministic=True,
        render=False,
    )
    progress_cb = EpisodeProgressCallback(
        MAX_EPISODES, start_episode, progress_path.with_suffix(""), progress_file
    )
    callbacks = [checkpoint_cb, eval_cb, progress_cb]
    if args.render:
        callbacks.append(TrainingRenderCallback(progress_cb))

    model.learn(
        total_timesteps=(MAX_EPISODES - start_episode) * MAX_EPISODE_STEPS,
        callback=callbacks,
        reset_num_timesteps=args.fresh or start_episode == 0,
    )
    if progress_cb.episodes >= MAX_EPISODES:
        final_model_path = final_path.with_suffix("")
        model.save(str(final_model_path))
        print(f"Training done after {progress_cb.episodes} episodes -> {final_path}")
    else:
        print(f"Training stopped at episode {progress_cb.episodes}; progress saved.")
    eval_env.close()
    env.close()


if __name__ == "__main__":
    main()